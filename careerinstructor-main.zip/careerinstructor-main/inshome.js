function navigateTo(page) {
    alert(`Navigating to ${page} page...`);
    // Here you would typically implement navigation logic, e.g., updating the URL or loading the respective component.
}

function goBack() {
    window.history.back();
}
